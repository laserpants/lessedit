?package(lessedit):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="lessedit" command="/usr/bin/lessedit"
